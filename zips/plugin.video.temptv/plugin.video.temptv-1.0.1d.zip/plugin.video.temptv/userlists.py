
# EXTM3U

english = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/english.txt'
hour24 = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/24-7.txt'
kids = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/kids.txt'
sports = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/sports.txt'
news = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/news.txt'
music = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/music.txt'
adult = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/adult.txt'
movies = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/movies.txt'
testing = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/testing.txt'
vod_4k_2019 = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/4k/vod-4k-2019.txt'
vod_4k_2018 = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/4k/vod-4k-2018.txt'
vod_4k_1993 = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/4k/vod-4k-1993.txt'
vod_1080p_2019 = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/1080/vod-1080p-2019.txt'
vod_1080p_2018 = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/1080/vod-1080p-2018.txt'
vod_720_2019 = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/720/vod-720p-2019.txt'
vod_720_2018 = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/720/vod-720p-2018.txt'

smallville = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/shows/smallville.txt'

uk = 'https://raw.githubusercontent.com/freearhey/iptv/master/channels/uk.m3u'
