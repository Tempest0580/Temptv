
# EXTM3U
# Source  https://www.en.m3uiptv.com/iptv-links-free-m3u-playlist-11-04-2019-2/

List1 = 'https://raw.githubusercontent.com/freearhey/iptv/master/channels/us.m3u'
List2 = 'https://raw.githubusercontent.com/freearhey/iptv/master/channels/uk.m3u'
List3 = 'https://textuploader.com/du2y3/rev/136'
List4 = 'https://textuploader.com/1dop6/raw'
hour24 = 'https://textuploader.com/1doe5/raw'
kids = 'https://textuploader.com/1doea/raw'