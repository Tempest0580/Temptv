
# EXTM3U

english = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/english.txt'
hour24 = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/24-7.txt'
kids = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/kids.txt'
sports = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/sports.txt'
news = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/news.txt'
music = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/music.txt'
adult = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/adult.txt'
movies = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/movies.txt'
pluto = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/pluto.txt'
testing = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/testing.txt'
click_4k_2019 = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/4k/click-4k-2019.txt'
click_4k_2018 = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/4k/click-4k-2018.txt'
click_4k_1993 = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/4k/click-4k-1993.txt'
click_1080p_2019 = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/1080/click-1080p-2019.txt'
click_1080p_2018 = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/1080/click-1080p-2018.txt'
click_1080p_2013 = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/1080/click-1080p-2013.txt'
click_720_2019 = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/720/click-720p-2019.txt'
click_720_2018 = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/720/click-720p-2018.txt'
vod_movies = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/vod_movies.txt'
vod_shows = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/vod_shows.txt'

smallville = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/shows/smallville.txt'
angermanagment = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/shows/angermanagment.txt'
familyguy = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/shows/familyguy.txt'

uk = 'https://raw.githubusercontent.com/freearhey/iptv/master/channels/uk.m3u'
