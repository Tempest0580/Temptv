
# EXTM3U
# Source  https://www.en.m3uiptv.com/iptv-links-free-m3u-playlist-11-04-2019-2/

List1 = 'https://raw.githubusercontent.com/freearhey/iptv/master/channels/us.m3u'
List2 = 'https://raw.githubusercontent.com/freearhey/iptv/master/channels/uk.m3u'
List3 = 'https://textuploader.com/du2y3/rev/136'
#List2 = 'http://128.199.182.109:8888/get.php?username=760bxx&password=malang&type=m3u'
#List3 = 'http://tvabertacanais.ml:8080/get.php?username=canais&password=36145544&type=m3u'
List4 = 'http://37.59.41.145:5050/get.php?username=admin&password=dreemedia&type=m3u'
List5 = 'http://189.213.148.234:9981/playlist'
List6 = 'http://151.80.100.155:25443/get.php?username=vodall&password=vrIzSCaxGN&type=m3u'
List7 = 'http://dynaiptv.tv:8010/get.php?username=Andre&password=Andre&type=m3u'


List8 = 'http://aika.dreamiptv.net:8080/get.php?username=QT1XLyk08v&password=70tOfMt6qG&type=m3u'

List9 = 'http://190.2.148.164:9977/get.php?username=69210&password=MOmYl3iRTn&type=m3u'

List10 = 'http://primestreams.tv:826/get.php?username=campsite&password=campsite&type=m3u'

List11 = 'http://31.220.1.190:8080/get.php?username=Jessica&password=Jessica1&type=m3u'

List12 = 'http://quatv2.com:8080/get.php?username=b&password=b&type=m3u'

List13 = 'http://quatv2.com:8080/get.php?username=marcia&password=marcia&type=m3u'

List14 = 'http://quatv2.com:8080/get.php?username=antonio&password=antonio&type=m3u'

List15 = 'http://quatv2.com:8080/get.php?username=denis&password=denis&type=m3u'

List16 = 'http://quatv2.com:8080/get.php?username=felipe&password=felipe&type=m3u'

List17 = 'http://quatv2.com:8080/get.php?username=antony&password=antony&type=m3u'

List18 = 'http://quatv2.com:8080/get.php?username=juliano&password=juliano&type=m3u'

List19 = 'http://quatv2.com:8080/get.php?username=leo2019&password=leo2019&type=m3u'

List20 = 'http://quatv2.com:8080/get.php?username=elias2019&password=elias2019&type=m3u'

List21 = 'http://quatv2.com:8080/get.php?username=nat2019&password=nat2019&type=m3u'

List22 = 'http://quatv2.com:8080/get.php?username=marx2019&password=marx2019&type=m3u'

List23 = 'http://quatv2.com:8080/get.php?username=lang&password=lang2019&type=m3u'

List24 = 'http://quatv2.com:8080/get.php?username=denis1&password=denis1&type=m3u'

List25 = 'http://quatv2.com:8080/get.php?username=andre1&password=andre1&type=m3u'

List26 = 'http://quatv2.com:8080/get.php?username=amauri1&password=amauri1&type=m3u'

List27 = 'http://primestreams.tv:826/get.php?username=Keith&password=Keith1&type=m3u'

List28 = 'http://dynaiptv.tv:8010/get.php?username=Andre&password=Andre&type=m3u'

List29 = 'http://iptvtool.es:9977/get.php?username=69210&password=MOmYl3iRTn&type=m3u'

List30 = 'http://37.59.41.145:5050/get.php?username=admin&password=dreemedia&type=m3u'

List31 = 'http://kimbogrupol.com:25461/get.php?username=Luis&password=1234&type=m3u'

List32 = 'http://kimbogrupol.com:25461/get.php?username=Nelson123&password=Nelson123&type=m3u'

List33 = 'http://bldtv.vip/get.php?username=coco&password=coco123&type=m3u'

List34 = 'http://kimbogrupol.com:25461/get.php?username=filiberto&password=filiberto&type=m3u'

List35 = 'http://bldtv.vip/get.php?username=dione01&password=dione01&type=m3u'

List36 = 'http://kimbogrupol.com:25461/get.php?username=Oscar&password=Oscar&type=m3u'

List37 = 'http://acid.best:80/get.php?username=m40g2wP2Hs&password=r7A9ei8DgW&type=m3u'

List38 = 'http://acid.best:80/get.php?username=uBPXLXnkNv&password=YA1luvalu8&type=m3u'

List39 = 'http://acid.best:80/get.php?username=edmsKepJwv&password=eOOq7Wg62f&type=m3u'

List40 = 'http://acid.best:80/get.php?username=ZhSRTaqBPg&password=aqT5hniVHq&type=m3u'

List41 = 'http://acid.best:80/get.php?username=Ogx8tPooGW&password=JZ6Sa1lNiy&type=m3u'

List42 = 'http://acid.best:80/get.php?username=DBPWvwUoOk&password=sO0hgo4Ar3&type=m3u'

List43 = 'http://acid.best:80/get.php?username=YHEHIIJJYV&password=rbvmspuYDm&type=m3u'

List44 = 'http://acid.best:80/get.php?username=Z90C5NDODy&password=zueJ5MUwzt&type=m3u'

List45 = 'http://acid.best:80/get.php?username=IBfsPMM4ZU&password=IlrIsP6IHg&type=m3u'

List46 = 'http://siptv-online.com:8789/get.php?username=27647&password=DtB0OJy2s3&type=m3u'

List47 = 'http://viptk.servervip.eu:80/get.php?username=burak01&password=01102018&type=m3u'

List48 = 'http://mrsatstream2.ddns.net:80/get.php?username=edmsKepJwv&password=eOOq7Wg62f&type=m3u'

List49 = 'http://mrsatstream2.ddns.net:80/get.php?username=m40g2wP2Hs&password=r7A9ei8DgW&type=m3u'

List50 = 'http://iptv.mecccam.com:8010/get.php?username=Andre&password=Andre&type=m3u'

List51 = 'http://acid.best:80/get.php?username=uBPXLXnkNv&password=YA1luvalu8&type=m3u'

List52 = 'http://185.165.243.104:25461/get.php?username=roma&password=roma&type=m3u'

List53 = 'http://tdbs.myddns.me/get.php?username=cqe8ZtUXaH&password=u8DcxumySP&type=m3u'

List54 = 'http://185.165.243.104:25461/get.php?username=berti&password=berti&type=m3u'

List55 = 'http://x.mytvxweb.me:25461/get.php?username=video_club&password=video_club1&type=m3u'

List56 = 'http://212.8.248.71:8000/get.php?username=simpli&password=simpli&type=m3u'

List57 = 'http://185.165.243.104:25461/get.php?username=alessandra&password=alessandra&type=m3u'

List58 = 'http://formen1.com:8080/get.php?username=emine16&password=28052018&type=m3u'

List59 = 'http://bymovistar.es:9977/get.php?username=69210&password=MOmYl3iRTn&type=m3u'

List60 = 'http://tv.sigma-iptv.net:7000/get.php?username=39308&password=MziznYlqZb&type=m3u'

List61 = 'http://149.ip-51-38-239.eu:8000/get.php?username=9635222312&password=5445223621&type=m3u'

List62 = 'http://93.118.32.94:8000/get.php?username=For_free&password=ipmagtv.com&type=m3u'

List63 = 'http://hd.iptv-passion.com:2095/get.php?username=8gVEZwhtic&password=orbE5eWXq7&type=m3u'

List64 = 'http://149.56.25.205:80/get.php?username=2000&password=1234&type=m3u'

List65 = 'http://46.166.142.124:8000/get.php?username=1994&password=1234&type=m3u'

List66 = 'http://quatv2.com:8880/get.php?username=1387&password=1387&type=m3u'

List67 = 'http://fonte.iptvmaishd.com:8880/get.php?username=2200&password=2200&type=m3u'

List68 = 'http://fonte.iptvmaishd.com:8880/get.php?username=2585&password=2585&type=m3u'

List69 = 'http://fonte.iptvmaishd.com:25461/get.php?username=roma&password=roma&type=m3u'

List70 = 'http://fonte.iptvmaishd.com:25461/get.php?username=SANTIAGO&password=SANTIAGO&type=m3u'

List71 = 'http://fonte.iptvmaishd.com:25461/get.php?username=Zelda&password=Zelda&type=m3u'

List72 = 'http://fonte.iptvmaishd.com:25461/get.php?username=raquel&password=raquel&type=m3u'

List73 = 'http://eir4.pikaflik.co.uk/playlist.m3u?type=m3u&channelId=178&deviceMac=00:1A:79:BE:2F:F6&uid=1615'

List74 = 'http://xtfreeme.zapto.org:8091/get.php?username=MF09YLlN3Z&password=Rd1BB76mGS&type=m3u'

List75 = 'http://mondial.cybergroup.top:8000/get.php?username=Frutta&password=Frutta&type=m3u'

List76 = 'http://iptvfree1.com:6969/get.php?username=live:iptvplanet&password=M6MaPB7VUJ&type=m3u'

List77 = 'http://66.70.189.59:8080/get.php?username=line2&password=ovh1&type=m3u'

List78 = 'http://hd.iptv-passion.com:2095/get.php?username=8gVEZwhtic&password=orbE5eWXq7&type=m3u'

List79 = 'http://www.freeiptvdaily.net:8000/get.php?username=35622545151&password=02223572232&type=m3u'

List80 = 'http://www.sansat.net:25461/get.php?username=jack1223y3&password=sIv2ghT9LT&type=m3u'

List81 = 'http://tektv.co/get.php?username=rachida&password=1234&type=m3u'

List82 = 'http://hd.iptv-passion.com:8000/get.php?username=8gVEZwhtic&password=orbE5eWXq7&type=m3u'

List83 = 'http://iptvfree1.com:6969/get.php?username=live:iptvplanet&password=M6MaPB7VUJ&type=m3u'

List84 = 'http://ipthost.com:25461/get.php?username=Home&password=Home&type=m3u'

List85 = 'http://185.246.209.218/get.php?username=philbrousseau@hotmail.com&password=c6u4UIw55z&type=m3u'

List86 = 'http://iptv4u.electro-clair.tech/get.php?username=ip251arb&password=251ip&type=m3u'

List87 = 'http://hd.007iptv.com:2095/get.php?username=8gVEZwhtic&password=orbE5eWXq7&type=m3u'

List88 = 'http://tv.iptvsensation.org:6500/get.php?username=v7cEyu35Bt&password=X5IaaEu6Js&type=m3u'

List89 = 'http://streamtv.com.br:8880/get.php?username=malek&password=malek&type=m3u'

List90 = 'http://tv.iptvsensation.org:6500/get.php?username=v7cEyu35Bt&password=X5IaaEu6Js&type=m3u'

List91 = 'http://tptv.cz:80/get.php?username=Khormi&password=sPamoRZLmE&type=m3u'

List92 = 'http://quatv2.com:2082/get.php?username=7768&password=7768&type=m3u'

List93 = 'http://163.172.82.81:50100/get.php?username=Stark&password=Stark&type=m3u'

List94 = 'http://quatv2.com:8880/get.php?username=11577&password=11577&type=m3u'

List95 = 'http://kimbogrupol.com:25461/get.php?username=Luis&password=1234&type=m3u'

List96 = 'http://149.ip-51-38-239.eu:8000/get.php?username=655626565&password=587896415&type=m3u'

List97 = 'http://185.165.243.104:25461/get.php?username=Malu&password=Malu&type=m3u'

List98 = 'http://xx.servelive.net:80/get.php?username=leonardo2&password=leonardo3&type=m3u'

List99 = 'http://edr.akiptv.biz:8000/get.php?username=eryilmaz1&password=eryilmaz123&type=m3u'

List100 = 'http://xx2.servelive.net:80/get.php?username=Kelly&password=123456&type=m3u'

List101 = 'http://sv1.mayootv.ovh:1914/get.php?username=medoum1&password=FH6Oxe1vOH&type=m3u'

List102 = 'http://bldtv.vip:80/get.php?username=Ederson&password=1234&type=m3u' 

List103 = 'http://clienteworld.com:8080/get.php?username=ione&password=ione&type=m3u' 

List104 = 'http://viptv2.dyndns.tv:2086/get.php?username=kronos&password=1234&type=m3u' 

List105 = 'http://maxptv.ddns.net:25461/get.php?username=Itamar&password=1234&type=m3u' 


List106 = 'http://maxptv.ddns.net:25461/get.php?username=Erica&password=1234&type=m3u' 
List107 = 'http://maxptv.ddns.net:25461/get.php?username=Eliete&password=1234&type=m3u'
List108 = 'http://maxptv.ddns.net:25461/get.php?username=Cleiton&password=1234&type=m3u'
List109 = 'http://eir4.pikaflik.co.uk:80/playlist.m3u?type=m3u&channelId=367&deviceMac=00:1A:79:BE:2F:F6&uid=1615'
List110 = 'http://mrsatstream2.ddns.net:80/get.php?username=plinio1&password=plinio2&type=m3u' 
List112 = 'http://46.166.148.101:8000/get.php?username=uvV9QK3Y4s&password=zMB5nK1Bcl&type=m3u' 
List114 = 'http://163.172.7.148:3456/get.php?username=FREEaleks&password=zZxvtXb5PL&type=m3u' 
List125 = 'http://128.199.182.109:8888/get.php?username=760bxx&password=malang&type=m3u'
List126 = 'http://163.172.35.210:8000/get.php?username=teqifsharopt&password=donmevjedh&type=m3u'
List129 = 'http://jack.dyndns.tv:15800/get.php?username=angelo1&password=angelo1&type=m3u'
List130 = 'http://tvabertacanais.ml:8080/get.php?username=canais&password=36145544&type=m3u'
List131 = 'http://151.80.100.155:25443/get.php?username=vodall&password=vrIzSCaxGN&type=m3u'
List132 = 'http://pro.falconiptv.com:25461/get.php?username=55sw3k7&password=4994md6&type=m3u'
List142 = 'http://92.30.108.254:8003/playlist.m3u8'
List145 = 'http://92.42.8.6:8000/playlist.m3u8'
List146 = 'http://134.209.75.14:9981/playlist'
List150 = 'http://85.0.26.89:7777/playlist.m3u8'
List153 = 'http://189.213.148.234:9981/playlist'
