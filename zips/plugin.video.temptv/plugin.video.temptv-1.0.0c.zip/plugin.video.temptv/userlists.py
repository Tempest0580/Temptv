
# EXTM3U

english = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/english.txt'
hour24 = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/24-7.txt'
kids = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/kids.txt'
sports = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/sports.txt'
news = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/news.txt'
music = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/music.txt'
adult = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/adult.txt'
movies = 'https://raw.githubusercontent.com/Tempest0580/Temptv/master/lists/movies.txt'

uk = 'https://raw.githubusercontent.com/freearhey/iptv/master/channels/uk.m3u'
